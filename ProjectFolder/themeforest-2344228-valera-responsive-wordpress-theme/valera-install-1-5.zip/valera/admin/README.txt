All questions and setup instructions please go to http://aquagraphite.com/2011/09/29/slightly-modded-options-framework/

@author - Syamil MJ
@author - URI http://aquagraphite.com
@title  - Slightly Modded Options Framework SMOF
@description - Options frameworks for WordPress Themes
@version - 1.4.0
@license - WTFPL - http://sam.zoy.org/wtfpl/

Changelog:

V 1.4.0 - 16 APRIL 2012
- add folding checkbox group option (credits to plovs - https://github.com/plovs)
- add sample grouped options
- add transfer option
- fix css quirks on some options
- single call to admin/admin.php from functions.php
- unique database name for options & backup
- replaced ereg_replace function (deprecated in PHP 5.3)
- uses add_theme_page to replace add_submenu_page
- reorganized files, paths etc
- delete background option
- delete child types
- everything a bit faster now
- change reset method